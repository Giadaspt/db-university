-- phpMyAdmin SQL Dump
-- version 4.9.5
-- https://www.phpmyadmin.net/
--
-- Host: localhost:8889
-- Generation Time: Jan 12, 2022 at 01:25 PM
-- Server version: 5.7.24
-- PHP Version: 7.4.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_university`
--

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE `students` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `degree_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `surname` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `date_of_birth` date NOT NULL,
  `fiscal_code` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `enrolment_date` date NOT NULL,
  `registration_number` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`date_of_birth`) VALUES
('1990-01-03'),
('1990-01-04'),
('1990-01-04'),
('1990-01-06'),
('1990-01-09'),
('1990-01-10'),
('1990-01-12'),
('1990-01-14'),
('1990-01-26'),
('1990-01-27'),
('1990-01-28'),
('1990-01-29'),
('1990-01-30'),
('1990-01-30'),
('1990-01-31'),
('1990-01-31'),
('1990-02-04'),
('1990-02-06'),
('1990-02-06'),
('1990-02-10'),
('1990-02-21'),
('1990-02-23'),
('1990-02-25'),
('1990-02-27'),
('1990-03-02'),
('1990-03-03'),
('1990-03-05'),
('1990-03-07'),
('1990-03-08'),
('1990-03-10'),
('1990-03-10'),
('1990-03-12'),
('1990-03-12'),
('1990-03-14'),
('1990-03-14'),
('1990-03-17'),
('1990-03-23'),
('1990-03-27'),
('1990-03-30'),
('1990-04-01'),
('1990-04-04'),
('1990-04-05'),
('1990-04-05'),
('1990-04-06'),
('1990-04-12'),
('1990-04-17'),
('1990-04-20'),
('1990-04-22'),
('1990-04-24'),
('1990-04-26'),
('1990-04-26'),
('1990-04-26'),
('1990-04-26'),
('1990-04-26'),
('1990-04-28'),
('1990-04-29'),
('1990-04-29'),
('1990-04-29'),
('1990-04-29'),
('1990-04-30'),
('1990-05-02'),
('1990-05-02'),
('1990-05-03'),
('1990-05-07'),
('1990-05-09'),
('1990-05-09'),
('1990-05-11'),
('1990-05-14'),
('1990-05-19'),
('1990-05-21'),
('1990-05-24'),
('1990-05-25'),
('1990-05-30'),
('1990-05-30'),
('1990-05-30'),
('1990-06-01'),
('1990-06-01'),
('1990-06-02'),
('1990-06-07'),
('1990-06-08'),
('1990-06-11'),
('1990-06-16'),
('1990-06-20'),
('1990-06-28'),
('1990-07-04'),
('1990-07-07'),
('1990-07-08'),
('1990-07-08'),
('1990-07-11'),
('1990-07-12'),
('1990-07-13'),
('1990-07-18'),
('1990-07-19'),
('1990-07-25'),
('1990-07-25'),
('1990-07-27'),
('1990-07-27'),
('1990-07-28'),
('1990-07-31'),
('1990-07-31'),
('1990-08-04'),
('1990-08-05'),
('1990-08-09'),
('1990-08-10'),
('1990-08-11'),
('1990-08-12'),
('1990-08-13'),
('1990-08-14'),
('1990-08-15'),
('1990-08-19'),
('1990-08-26'),
('1990-08-26'),
('1990-08-26'),
('1990-08-28'),
('1990-08-29'),
('1990-08-30'),
('1990-09-02'),
('1990-09-03'),
('1990-09-07'),
('1990-09-09'),
('1990-09-12'),
('1990-09-14'),
('1990-09-15'),
('1990-09-17'),
('1990-09-19'),
('1990-09-20'),
('1990-10-03'),
('1990-10-10'),
('1990-10-12'),
('1990-10-14'),
('1990-10-16'),
('1990-10-16'),
('1990-10-16'),
('1990-10-17'),
('1990-10-21'),
('1990-10-21'),
('1990-10-24'),
('1990-10-28'),
('1990-10-30'),
('1990-11-13'),
('1990-11-14'),
('1990-11-14'),
('1990-11-15'),
('1990-11-17'),
('1990-11-18'),
('1990-11-18'),
('1990-11-21'),
('1990-11-26'),
('1990-11-27'),
('1990-11-28'),
('1990-12-03'),
('1990-12-04'),
('1990-12-06'),
('1990-12-18'),
('1990-12-18'),
('1990-12-18'),
('1990-12-21'),
('1990-12-28'),
('1990-12-28'),
('1990-12-28');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `students`
--
ALTER TABLE `students`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `students_email_unique` (`email`),
  ADD KEY `students_degree_id_foreign` (`degree_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `students`
--
ALTER TABLE `students`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5001;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `students`
--
ALTER TABLE `students`
  ADD CONSTRAINT `students_degree_id_foreign` FOREIGN KEY (`degree_id`) REFERENCES `degrees` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
